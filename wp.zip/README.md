
  # Design landing page for Programa Renace

  This is a code bundle for Design landing page for Programa Renace. The original project is available at https://www.figma.com/design/qDIYwUpyxUen6FKemCJOqh/Design-landing-page-for-Programa-Renace.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  